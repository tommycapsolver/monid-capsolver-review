# Tasks: add-connector-capsolver

## 1. Connector

- [x] 1.1 Add provider metadata, body authentication, error mapping, and task polling
- [x] 1.2 Add proxyless reCAPTCHA v2, reCAPTCHA v3, and Turnstile endpoints
- [x] 1.3 Add the `captcha-solving` leaf category and endpoint identity locks

## 2. Specification and verification

- [x] 2.1 Add the OpenSpec proposal and connector requirements
- [x] 2.2 Verify the public CapSolver MCP server over stdio
- [x] 2.3 Verify the connector with a synthetic async fixture
- [x] 2.4 Reach the live CapSolver API through the compiled connector with an invalid-key smoke test
- [x] 2.5 Run formatting, connector type checks, compilation, and connector tests
- [ ] 2.6 Record one authorized live solve after a test API key is provided
