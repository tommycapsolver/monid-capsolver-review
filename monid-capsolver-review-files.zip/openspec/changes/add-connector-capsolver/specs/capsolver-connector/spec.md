# capsolver-connector (delta)

## ADDED Requirements

### Requirement: CapSolver provider definition
The provider SHALL declare name `capsolver`, JSON-body `clientKey`
authentication, `https://api.capsolver.com` as its base URL, and the documented
asynchronous task lifecycle. Credentials SHALL be injected by the transport and
SHALL NOT appear in lifecycle state, logs, or fixtures.

#### Scenario: An asynchronous task reaches ready
- **WHEN** `createTask` returns a task id and `getTaskResult` progresses from
  `processing` to `ready`
- **THEN** the run completes with the final provider response and solution
- **AND** the successful endpoint's per-call usage is settled once

#### Scenario: The provider rejects a task
- **WHEN** CapSolver returns a non-zero `errorId` or an HTTP error
- **THEN** the run completes as a provider error
- **AND** usage is zero

### Requirement: Proxyless token endpoints
The connector SHALL expose `/solve/recaptcha-v2`, `/solve/recaptcha-v3`, and
`/solve/turnstile`. Each endpoint SHALL require `websiteURL` and `websiteKey`,
map the caller input to the corresponding CapSolver proxyless task type, and
use the public standard price for that task family.

#### Scenario: Solve a reCAPTCHA v2 challenge
- **WHEN** a caller submits an authorized page URL and public site key to
  `/solve/recaptcha-v2`
- **THEN** the wire request uses `ReCaptchaV2TaskProxyLess`
- **AND** the API key is injected as `clientKey` outside connector code

#### Scenario: Add optional Turnstile metadata
- **WHEN** a caller provides `action` or `cdata` to `/solve/turnstile`
- **THEN** the wire task includes a Turnstile metadata object
