# Proposal: add-connector-capsolver

## Why

CapSolver provides asynchronous CAPTCHA token tasks used in authorized browser
automation, QA, RPA, and public-web data workflows. Adding a native connector
lets Monid users call the same core solving service exposed by CapSolver's MCP
server without requiring Monid to host or proxy another MCP transport.

## What Changes

- Add a `capsolver` provider with JSON-body API-key authentication and the
  documented `createTask` -> `getTaskResult` lifecycle.
- Add proxyless reCAPTCHA v2, reCAPTCHA v3, and Cloudflare Turnstile endpoints.
- Add the `captcha-solving` leaf category.
- Model the three published standard rates in US dollars per completed task.

## Capabilities

- `capsolver-connector`.

## Non-goals

- Browser ownership, CAPTCHA detection, DOM token injection, or automatic
  retries inside a caller's browser session.
- Proxy-based and Enterprise task variants in the first change.
- Calling CapSolver's MCP server from Monid; the connector uses the provider's
  public REST API directly.

## Impact

New connector tree and one taxonomy leaf. No engine or schema changes.
