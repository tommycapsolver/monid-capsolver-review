import { defineEndpoint, UsageModelKind } from "@shared/core";
import { z } from "zod";
import { zWebsite } from "../../schema/common.ts";

const zBody = zWebsite.extend({
    action: z.string().min(1).optional(),
    cdata: z.string().min(1).optional(),
}).strict();

export default defineEndpoint({
    meta: {
        displayName: "Solve Cloudflare Turnstile",
        summary: "Create and complete a proxyless Turnstile token task.",
        description: "Submit a proxyless Cloudflare Turnstile challenge " +
            "and poll CapSolver until its token is ready.",
        docsUrl:
            "https://docs.capsolver.com/en/guide/captcha/CloudflareTurnstile/",
        categories: ["captcha-solving"],
    },
    endpoint: "/solve/turnstile",
    request: { method: "POST", path: "/createTask" },
    input: {
        schema: { body: zBody },
        toRequest: ({ data, utils }) => {
            const body = data.input.body ?? {};
            const action = utils.json.optionalGet(body, "$.action");
            const cdata = utils.json.optionalGet(body, "$.cdata");
            const task = utils.json.merge(
                utils.json.omit(body, ["action", "cdata"]),
                {
                    type: "AntiTurnstileTaskProxyLess",
                    ...(typeof action === "string" || typeof cdata === "string"
                        ? {
                            metadata: {
                                type: "turnstile",
                                ...(typeof action === "string"
                                    ? { action }
                                    : {}),
                                ...(typeof cdata === "string" ? { cdata } : {}),
                            },
                        }
                        : {}),
                },
            );
            return { ...data.input, body: { task } };
        },
    },
    usage: {
        model: {
            kind: UsageModelKind.PER_CALL,
            label: "completed Turnstile task",
            consumes: { credit: "default", amount: 0.0012 },
        },
    },
});
