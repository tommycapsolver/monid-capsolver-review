import { z } from "zod";

export const zWebsite = z.object({
    websiteURL: z.url().describe(
        "Full URL of the page that presents the CAPTCHA challenge.",
    ),
    websiteKey: z.string().min(1).describe(
        "Public site key from the CAPTCHA widget.",
    ),
}).strict();
