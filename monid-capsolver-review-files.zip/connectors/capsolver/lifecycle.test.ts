import { assertEquals } from "@std/assert";
import { fromFileUrl } from "@std/path";
import type { RunInput } from "@shared/core";
import { loadFixture, runEndpoint, testSealedUnit } from "@shared/testing";

const HERE = fromFileUrl(new URL("./", import.meta.url));
const INPUTS = JSON.parse(
    await Deno.readTextFile(`${HERE}test-inputs.json`),
) as Record<string, RunInput>;

Deno.test("capsolver: createTask is polled until a token is ready", async () => {
    const result = await runEndpoint({
        unit: await testSealedUnit("capsolver#solve/recaptcha-v2"),
        input: INPUTS["recaptcha-v2"],
        mode: "replay",
        fixture: await loadFixture(
            `${HERE}fixtures/synthetic-succeeded.json`,
        ),
    });
    assertEquals(result.httpStatus, 200);
    assertEquals(result.isProviderError, false);
    assertEquals(result.output, {
        errorId: 0,
        taskId: "synthetic-task-id",
        status: "ready",
        solution: { gRecaptchaResponse: "synthetic-token" },
    });
    assertEquals(result.usage, {
        credits: { default: 0.0008 },
        evidence: { CALL: 1 },
    });
});

Deno.test("capsolver: all three first-scope endpoints compile", async () => {
    for (
        const id of [
            "capsolver#solve/recaptcha-v2",
            "capsolver#solve/recaptcha-v3",
            "capsolver#solve/turnstile",
        ]
    ) {
        const unit = await testSealedUnit(id);
        assertEquals(unit.doc.provider, "capsolver");
    }
});
